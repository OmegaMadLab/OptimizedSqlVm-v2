# Change log for PSModulesDsc

## Unreleased

## 1.0.0.0

- First release of PowershellModule resource.
